<?php
/*Datos de conexion a la base de datos*/
define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'pensionsync');//Usuario de tu base de datos
define('DB_PASS', ',*TBeJT[LA8G');//Contraseña del usuario de la base de datos
define('DB_NAME', 'pensionsync');//Nombre de la base de datos

?>

